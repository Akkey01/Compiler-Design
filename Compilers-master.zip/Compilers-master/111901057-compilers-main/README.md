# 111901057-compilers

This is the README for the `Compilers Lab January - 2022 Semester`
Refer to the `SUMMARY` to see what all is implemented and what is left to be implemented.

## Code Structure

To run the code, run `Make tests` in the root directory.
All the tests are present 
The output of the `mips` code generated will be given in the `test.out`
The basicblocks and IR pretty printing is done in the `test.err` section.